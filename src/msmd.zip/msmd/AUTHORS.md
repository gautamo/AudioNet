Contributors
============

* Matthias Dorfer <https://github.com/dmatte>
* Jan Hajič jr. <https://github.com/hajicj>
* Andreas Arzt <https://github.com/aarzt>
* Harald Frostel
* Gerhard Widmer
* Stefan Balke <https://github.com/stefan-balke>
* Florian Henkel <https://github.com/fhenkel>
* Luis Carvalho <https://github.com/luisfvc>